export class Membership{

  id: number;

}
