export class Transaction{

  id: number;
   

}
