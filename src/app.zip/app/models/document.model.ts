export class Document
{

  id: number;
  document_type:any;
  document:any;

}
