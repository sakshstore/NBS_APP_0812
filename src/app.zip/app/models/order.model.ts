export class Order {
    id: any;
}
