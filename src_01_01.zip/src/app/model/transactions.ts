export class Transactions {
  
   
    id: string; 
	


}