import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { SupportDetailsPageRoutingModule } from './support-details-routing.module';

import { SupportDetailsPage } from './support-details.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    SupportDetailsPageRoutingModule
  ],
  declarations: [SupportDetailsPage]
})
export class SupportDetailsPageModule {}
