
export class Product {


    id: any;
    cover: any;
    name: any;
    sell_price: any;
    wholesale_price:any;
    quantity: any;
    net_price:any;
    descriptions:any;


}