export class User {
  
   
    id: string; 
	


}